for(var factor = 1; factor < 13; factor++){
	console.log(4*factor);
}